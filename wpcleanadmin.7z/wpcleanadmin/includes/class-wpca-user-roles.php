<?php
/**
 * WP Clean Admin - 用户角色管理模块
 *
 * @package     WP_Clean_Admin
 * @subpackage  User_Roles
 * @author      Sut
 * @copyright   2025 Sut
 * @license     GPL-2.0+
 * @link        https://github.com/sutchan/WP-Clean-Admin
 * @since       1.0.0
 */

if (!defined('ABSPATH')) exit;

/**
 * Class WPCA_User_Roles
 * 
 * 处理用户角色权限和设置访问控制
 */
class WPCA_User_Roles {
    public function __construct() {
        add_action('admin_init', array($this, 'init'));
    }

    public function init() {
        // Add role capabilities with validation
        $roles = apply_filters('wpca_managed_roles', ['editor', 'author', 'contributor']);
        foreach ($roles as $role_name) {
            $role = get_role($role_name);
            if ($role && is_a($role, 'WP_Role')) {
                $role->add_cap('wpca_customize_admin');
            } else {
                error_log("[WPCA] Invalid role: {$role_name}");
            }
        }
        
        // Only allow administrators to access settings
        if (!current_user_can('manage_options')) {
            add_filter('wpca_get_settings', array($this, 'filter_settings_for_roles'));
        }
    }

    public function filter_settings_for_roles($settings) {
        if (!current_user_can('manage_options')) {
            // Remove sensitive settings for non-admins
            $restricted = apply_filters('wpca_restricted_settings', [
                'hide_admin_menu_items',
                'hide_admin_bar_items',
                'menu_order'
            ]);
            
            foreach ($restricted as $key) {
                if (isset($settings[$key])) {
                    unset($settings[$key]);
                }
            }
        }
        return $settings;
    }
    
    public static function cleanup_roles() {
        $roles = ['editor', 'author', 'contributor'];
        foreach ($roles as $role_name) {
            $role = get_role($role_name);
            if ($role && is_a($role, 'WP_Role')) {
                $role->remove_cap('wpca_customize_admin');
            }
        }
    }
}