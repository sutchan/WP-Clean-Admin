<?php
/**
 * WP Clean Admin - 设置导出导入模块
 *
 * @package     WP_Clean_Admin
 * @subpackage  Export_Import
 * @author      Sut
 * @copyright   2025 Sut
 * @license     GPL-2.0+
 * @link        https://github.com/sutchan/WP-Clean-Admin
 * @since       1.0.0
 */

if (!defined('ABSPATH')) exit;

class WPCA_Export_Import {
    public function __construct() {
        add_action('admin_init', array($this, 'init'));
    }

    public function init() {
        // Handle export/import actions
        add_action('admin_post_wpca_export_settings', array($this, 'export_settings'));
        add_action('admin_post_wpca_import_settings', array($this, 'import_settings'));
    }

    public function export_settings() {
        check_admin_referer('wpca_export_nonce');
        
        if (!current_user_can('manage_options')) {
            wp_die(__('You do not have sufficient permissions to access this page.', 'wp-clean-admin'));
        }

        $settings = get_option('wpca_settings');
        header('Content-Disposition: attachment; filename="wpca-settings-export.json"');
        header('Content-Type: application/json');
        echo json_encode($settings);
        exit;
    }

    public function import_settings() {
        check_admin_referer('wpca_import_nonce');
        
        if (!current_user_can('manage_options') || 
            !isset($_FILES['wpca_import_file']) ||
            $_FILES['wpca_import_file']['size'] > 100000) {
            wp_die(__('Invalid request', 'wp-clean-admin'));
        }
        
        $file_type = wp_check_filetype($_FILES['wpca_import_file']['name']);
        if ($file_type['ext'] !== 'json') {
            wp_die(__('Invalid file type', 'wp-clean-admin'));
        }

        $file = $_FILES['wpca_import_file']['tmp_name'];
        $settings = json_decode(file_get_contents($file), true);
        
        if (json_last_error() === JSON_ERROR_NONE) {
            update_option('wpca_settings', $settings);
            wp_redirect(admin_url('options-general.php?page=wp_clean_admin&imported=1'));
        } else {
            wp_redirect(admin_url('options-general.php?page=wp_clean_admin&import_error=1'));
        }
        exit;
    }
}