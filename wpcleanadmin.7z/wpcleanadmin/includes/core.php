<?php
/**
 * WP Clean Admin - 核心加载文件
 *
 * @package     WP_Clean_Admin
 * @subpackage  Core
 * @copyright   Copyright (c) 2025, Sut
 * @license     http://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since       1.0.0
 */

// 确保在WordPress环境中运行
if (!defined('ABSPATH') || !defined('WP_CLEAN_ADMIN_PATH')) {
    status_header(403);
    die('Direct access forbidden');
}

// 检查必要常量是否定义
if (!defined('WP_CLEAN_ADMIN_FILE') || !defined('WP_CLEAN_ADMIN_VERSION')) {
    wp_die(__('Required constants are not defined', 'wp-clean-admin'));
}

/**
 * 插件激活函数
 */
function wpca_activate_plugin() {
    if (!current_user_can('activate_plugins')) {
        wp_die(__('You do not have sufficient permissions to activate this plugin.', 'wp-clean-admin'));
    }
    
    // 初始化默认设置
    $defaults = [
        'menu_order' => [],
        'menu_hidden_items' => [],
        'theme_style' => 'default'
    ];
    
    if (!get_option('wpca_settings')) {
        update_option('wpca_settings', $defaults);
    }
    
    // 添加定时任务
    if (!wp_next_scheduled('wpca_daily_maintenance')) {
        wp_schedule_event(time(), 'daily', 'wpca_daily_maintenance');
    }
}

/**
 * 插件卸载函数
 */
function wpca_uninstall_plugin() {
    if (!current_user_can('delete_plugins')) {
        return;
    }
    
    // 清理插件选项
    delete_option('wpca_settings');
    delete_option('wpca_menu_settings');
    
    // 移除定时任务
    wp_clear_scheduled_hook('wpca_daily_maintenance');
}

// 初始化插件
add_action('plugins_loaded', 'wpca_initialize_plugin');

/**
 * 插件初始化函数
 */
function wpca_initialize_plugin() {
    // 加载多语言
    load_plugin_textdomain(
        'wp-clean-admin',
        false,
        dirname(plugin_basename(WP_CLEAN_ADMIN_FILE)) . '/languages/'
    );
    
    // 注册其他模块
    if (is_admin()) {
        // 加载样式和脚本
        add_action('admin_enqueue_scripts', 'wpca_load_admin_assets');
    }
}

/**
 * 加载管理界面资源
 * - 仅对具有管理权限的用户加载
 * - 记录资源加载错误
 */
function wpca_load_admin_assets() {
    if (!current_user_can('manage_options')) {
        return;
    }

    // 添加资源验证过滤器
    add_filter('style_loader_src', function($src) {
        if (strpos($src, 'wp-clean-admin') !== false) {
            $local_path = str_replace(content_url(), WP_CONTENT_DIR, $src);
            if (!file_exists($local_path)) {
                error_log("[WPCA] Missing stylesheet: " . basename($local_path));
                return false;
            }
        }
        return $src;
    }, 10, 2);

    try {
        // 主样式文件（增加存在性检查）
        $main_css = plugins_url('assets/css/wp-clean-admin.css', WP_CLEAN_ADMIN_FILE);
        if (apply_filters('wpca_load_style', true, 'main')) {
            wp_enqueue_style(
                'wp-clean-admin',
                $main_css,
                [],
                WP_CLEAN_ADMIN_VERSION
            );
        }
        
        // 菜单切换样式
        wp_enqueue_style(
            'wp-clean-admin-menu-toggle',
            plugins_url('assets/css/admin.css', WP_CLEAN_ADMIN_FILE),
            ['wp-clean-admin'],
            WP_CLEAN_ADMIN_VERSION
        );
        
        // 菜单排序样式
        wp_enqueue_style(
            'wp-clean-admin-menu',
            plugins_url('assets/css/admin.css', WP_CLEAN_ADMIN_FILE),
            ['wp-clean-admin'],
            WP_CLEAN_ADMIN_VERSION
        );
        
        // 管理界面样式
        wp_enqueue_style(
            'wp-clean-admin-settings',
            plugins_url('assets/css/admin.css', WP_CLEAN_ADMIN_FILE),
            ['wp-clean-admin'],
            WP_CLEAN_ADMIN_VERSION
        );
        
        // 加载jQuery UI
        wp_enqueue_script('jquery-ui-sortable');
        wp_enqueue_script('jquery-ui-tabs');
        
        // 加载管理界面脚本
        wp_enqueue_script(
            'wp-clean-admin-admin',
            plugins_url('assets/js/admin.js', WP_CLEAN_ADMIN_FILE),
            ['jquery', 'jquery-ui-sortable', 'jquery-ui-tabs'],
            WP_CLEAN_ADMIN_VERSION,
            true
        );
    } catch (Exception $e) {
        error_log('WPCA Assets Error: ' . $e->getMessage());
    }
}

// 安全加载功能模块
$modules = [
    'menu' => __DIR__ . '/class-wpca-admin-menu.php',
    'performance' => __DIR__ . '/class-wpca-admin-performance.php',
    'settings' => __DIR__ . '/class-wpca-admin-settings.php'
];

foreach ($modules as $name => $path) {
    if (!file_exists($path)) {
        error_log("[WPCA] Missing module: {$name} ({$path})");
        continue;
    }
    
    try {
        require_once $path;
    } catch (Exception $e) {
        error_log("[WPCA] Module load error: {$name} - " . $e->getMessage());
    }
}

// 验证核心类加载状态
if (!class_exists('WPCA_Admin_Menu') || 
    !class_exists('WPCA_Admin_Performance') ||
    !class_exists('WPCA_Admin_Settings')) {
    error_log('[WPCA] Error: Essential classes not loaded');
    return;
}

// 标记模块加载完成
if (!defined('WPCA_MODULES_LOADED')) {
    define('WPCA_MODULES_LOADED', true);
}

// 注册卸载钩子
register_uninstall_hook(WP_CLEAN_ADMIN_FILE, 'wpca_uninstall_plugin');

// 添加维护钩子
add_action('wpca_daily_maintenance', function() {
    // 每日清理临时数据
    error_log('[WPCA] Performing daily maintenance');
});