<?php
/**
 * Admin Menu Customizer
 * 
 * @package WPCleanAdmin
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

if (!function_exists('wp_doing_ajax')) {
    require_once ABSPATH . 'wp-admin/includes/ajax-actions.php';
}
if (!function_exists('current_user_can')) {
    require_once ABSPATH . 'wp-includes/capabilities.php';
}
if (!function_exists('sanitize_key')) {
    require_once ABSPATH . 'wp-includes/formatting.php';
}
if (!function_exists('menu_page_url')) {
    require_once ABSPATH . 'wp-admin/includes/plugin.php';
}
if (!function_exists('remove_menu_page')) {
    require_once ABSPATH . 'wp-admin/includes/menu.php';
}
if (!function_exists('check_ajax_referer')) {
    require_once ABSPATH . 'wp-includes/pluggable.php';
}
if (!function_exists('wp_send_json_error')) {
    require_once ABSPATH . 'wp-includes/functions.php';
}
if (!function_exists('wp_enqueue_style')) {
    require_once ABSPATH . 'wp-includes/script-loader.php';
}
if (!function_exists('plugins_url')) {
    require_once ABSPATH . 'wp-includes/link-template.php';
}
/**
 * WP Clean Admin - 菜单管理模块
 * 
 * 合并原menu-manager.php和menu-customizer.php功能
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * WP Clean Admin - 菜单管理核心类
 *
 * 功能：
 * - 菜单项显隐控制
 * - 子菜单管理
 * - 菜单排序
 * - 权限验证
 *
 * @since 1.0.0
 */
class WPCA_Admin_Menu {
    private static $instance;
    
    /**
     * 获取单例实例
     * @return WPCA_Admin_Menu
     */
    public static function get_instance() {
        if (!isset(self::$instance)) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        add_action('admin_init', [$this, 'register_settings']);
        add_action('admin_menu', [$this, 'modify_admin_menu'], 999);
        
        // 来自menu-customizer的功能初始化
        add_action('admin_enqueue_scripts', [$this, 'enqueue_assets']);
        
        // 注册AJAX处理
        add_action('wp_ajax_wpca_toggle_menu_item', [$this, 'ajax_toggle_menu_item']);
    }
    
    // 注册设置项
    public function register_settings() {
        register_setting('wpca_menu', 'wpca_hidden_menus', [
            'type' => 'array',
            'sanitize_callback' => [$this, 'sanitize_array'],
            'default' => []
        ]);
        
        register_setting('wpca_menu', 'wpca_hidden_submenus', [
            'type' => 'array',
            'sanitize_callback' => [$this, 'sanitize_array'],
            'default' => []
        ]);

        register_setting('wpca_menu', 'wpca_menu_order', [
            'type' => 'array',
            'sanitize_callback' => [$this, 'sanitize_array'],
            'default' => []
        ]);
    }
    
    // 数据清理
    public function sanitize_array($input) {
        return is_array($input) ? $input : [];
    }
    
    /**
     * 修改后台菜单结构
     * - 隐藏指定菜单项
     * - 重新排序菜单
     * - 需要manage_options权限
     */
    public function modify_admin_menu() {
        if (!current_user_can('manage_options')) {
            return;
        }

        $hidden_menus = get_option('wpca_hidden_menus', []);
        $hidden_submenus = get_option('wpca_hidden_submenus', []);
        $menu_order = get_option('wpca_menu_order', []);
        
        // 隐藏菜单项
        if (!empty($hidden_menus)) {
            foreach ($hidden_menus as $menu_slug) {
                $slug = sanitize_key($menu_slug);
                if ($slug && menu_page_url($slug, false)) {
                    remove_menu_page($slug);
                } else {
                    error_log("[WPCA] Invalid menu slug: {$menu_slug}");
                }
            }
        }
        
        // 隐藏子菜单
        if (!empty($hidden_submenus)) {
            foreach ($hidden_submenus as $submenu) {
                if (is_string($submenu) && strpos($submenu, '|') !== false) {
                    list($parent_slug, $child_slug) = explode('|', $submenu, 2);
                    remove_submenu_page(
                        sanitize_key($parent_slug), 
                        sanitize_key($child_slug)
                    );
                }
            }
        }

        // 重新排序菜单
        if (!empty($menu_order) && is_array($menu_order)) {
            global $menu;
            
            // 备份原始菜单项
            $original_menu = $menu;
            $ordered_menu = [];
            $remaining_items = $original_menu;
            
            // 按顺序添加菜单项
            foreach ($menu_order as $slug) {
                foreach ($remaining_items as $key => $item) {
                    if (isset($item[2]) && $item[2] === $slug) {
                        $ordered_menu[] = $item;
                        unset($remaining_items[$key]);
                        break;
                    }
                }
            }
            
            // 添加未排序的剩余菜单项
            $menu = array_merge($ordered_menu, $remaining_items);
        }
    }
    
    /**
     * AJAX处理菜单状态切换
     */
    public function ajax_toggle_menu_item() {
        check_ajax_referer('wpca_menu_order_nonce', 'nonce');
        
        if (!current_user_can('manage_options') || 
            !wp_doing_ajax() ||
            empty($_SERVER['HTTP_X_REQUESTED_WITH']) || 
            strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) != 'xmlhttprequest') {
            wp_send_json_error(['message' => __('Invalid request', 'wp-clean-admin')], 403);
        }

        $menu_slug = isset($_POST['menu_slug']) ? sanitize_key($_POST['menu_slug']) : '';
        $hidden = isset($_POST['hidden']) ? (bool)$_POST['hidden'] : false;
        
        if (empty($menu_slug)) {
            wp_send_json_error(['message' => __('Invalid menu slug', 'wp-clean-admin')]);
        }

        // 实际处理逻辑...
        wp_send_json_success(['status' => $hidden]);
    }

    // 加载资源 (来自menu-customizer)
    public function enqueue_assets() {
        wp_enqueue_style(
            'wpca-menu-customizer',
            plugins_url('assets/css/admin.css', WP_CLEAN_ADMIN_FILE),
            [],
            WP_CLEAN_ADMIN_VERSION
        );
        
        wp_enqueue_script(
            'wpca-menu-customizer',
            plugins_url('assets/js/wpca-menu-customizer.js', WP_CLEAN_ADMIN_FILE),
            ['jquery', 'jquery-ui-sortable'],
            WP_CLEAN_ADMIN_VERSION,
            true
        );

        wp_localize_script(
            'wpca-menu-customizer',
            'wpcaMenuData',
            [
                'ajaxUrl' => admin_url('admin-ajax.php'),
                'nonce' => wp_create_nonce('wpca_menu_nonce'),
                'submenuStates' => get_option('wpca_submenu_states', []),
                'locale' => get_locale()
            ]
        );
    }
} // 类闭合大括号

// 初始化
if (defined('WP_CLEAN_ADMIN_FILE')) {
    WPCA_Admin_Menu::get_instance();
} else {
    error_log('[WPCA] Error: Plugin constants not defined');
}