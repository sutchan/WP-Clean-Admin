<?php
/**
 * Plugin Name: WP Clean Admin
 * Plugin URI: https://github.com/sutchan/WP-Clean-Admin
 * Description: WordPress后台优化插件，提供菜单管理、性能优化和界面自定义功能
 * Version: 1.0.0
 * Author: Sut
 * Author URI: https://github.com/sutchan
 * License: GPL-2.0+
 * License URI: http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain: wp-clean-admin
 * Domain Path: /languages
 * 
 * WP Clean Admin - WordPress后台优化插件
 *
 * @package     WP_Clean_Admin
 * @version     1.0.0
 * @author      Sut
 * @copyright   2025 Sut
 * @license     GPL-2.0+
 * @link        https://github.com/sutchan/WP-Clean-Admin
 * 
 * 主要功能：
 * - 后台菜单管理
 * - 性能优化
 * - 界面自定义
 * - 多语言支持
 */

// 严格的安全检查
if (!defined('ABSPATH') || !defined('WPINC')) {
    if (function_exists('status_header')) {
        status_header(403);
    }
    header('HTTP/1.1 403 Forbidden');
    die('Direct access forbidden');
}

// 环境验证
if (!function_exists('add_action')) {
    die('WordPress environment required');
}

if (version_compare(get_bloginfo('version'), '5.6', '<')) {
    wp_die(__('WP Clean Admin requires WordPress 5.6+', 'wp-clean-admin'));
}

// 定义插件常量
define('WP_CLEAN_ADMIN_VERSION', '1.0.0');
define('WP_CLEAN_ADMIN_FILE', __FILE__);

$wpca_path = plugin_dir_path(WP_CLEAN_ADMIN_FILE);
if (!is_dir($wpca_path . 'includes')) {
    wp_die(__('Plugin files are missing or corrupted', 'wp-clean-admin'));
}
define('WP_CLEAN_ADMIN_PATH', $wpca_path);

// 加载核心功能
require_once WP_CLEAN_ADMIN_PATH . 'includes/core.php';
if (!function_exists('wpca_initialize_plugin')) {
    wp_die(__('Failed to load plugin core', 'wp-clean-admin'));
}

// 注册激活和卸载钩子
register_activation_hook(__FILE__, 'wpca_activate_plugin');
register_uninstall_hook(__FILE__, 'wpca_uninstall_plugin');

// 初始化插件
add_action('plugins_loaded', 'wpca_initialize_plugin');

// 添加插件设置链接
add_action('plugins_loaded', function() {
    // 验证管理界面可用性
    if (!function_exists('admin_url') || !function_exists('plugin_basename')) {
        return;
    }

    add_filter('plugin_action_links_' . plugin_basename(__FILE__), function($links) {
        $settings_url = admin_url('options-general.php?page=wp_clean_admin');
        if (empty($settings_url)) {
            return $links;
        }
        
        $settings_link = '<a href="' . esc_url($settings_url) . '">' . 
                        __('设置', 'wp-clean-admin') . '</a>';
        array_unshift($links, $settings_link);
        return $links;
    });

    // 添加插件元数据
    add_filter('plugin_row_meta', function($links, $file) {
        if (plugin_basename(__FILE__) === $file) {
            $row_meta = [
                'docs' => '<a href="' . esc_url('https://github.com/sutchan/WP-Clean-Admin/wiki') . 
                          '" target="_blank" rel="noopener">' . __('文档', 'wp-clean-admin') . '</a>',
                'support' => '<a href="' . esc_url('https://github.com/sutchan/WP-Clean-Admin/issues') . 
                            '" target="_blank" rel="noopener">' . __('支持', 'wp-clean-admin') . '</a>'
            ];
            return array_merge($links, $row_meta);
        }
        return $links;
    }, 10, 2);
});